const mysql = require('mysql');

// Connection Pool
let pool = mysql.createPool({
  connectionLimit: 10,
  host:    process.env.DB_HOST,
  user:    process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
});


// View Users
exports.view = (req, res) => {
  pool.query('SELECT * FROM user WHERE status = "active"', (err, rows) => {
    if (!err) {
      let removedUser = req.query.removed;
      res.render('home', { rows, removedUser });
    } else {
      console.log(err);
    }
    console.log('The data from user table: \n', rows);
  });
}

// Find User by Search
exports.find = (req, res) => {
  let searchTerm = req.body.search;
  pool.query('SELECT * FROM user WHERE First_Name LIKE ? OR Last_Name LIKE ?', ['%' + searchTerm + '%', '%' + searchTerm + '%'], (err, rows) => {
    if (!err) {
      res.render('home', { rows });
    } else {
      console.log(err);
    }
  });
};


// Display add user form
exports.form = (req, res) => {
  res.render('add-user');
};



// Add new user
exports.create = (req, res) => {
  const { First_Name, Last_Name, Location, Email, Education, About } = req.body;
  pool.query('INSERT INTO user SET ?', { First_Name, Last_Name, Location, Email, Education, About }, (err, rows) => {
    if (!err) {
      res.render('add-user', { alert: 'User added successfully.' });
    } else {
      console.log(err);
    }
  });
};


// Edit user
exports.edit = (req, res) => {
  pool.query('SELECT * FROM user WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      res.render('edit-user', { rows });
    } else {
      console.log(err);
    }
  });
};


exports.update = (req, res) => {
  const { First_Name, Last_Name, Location, Email, Education, About } = req.body;
  pool.query('UPDATE user SET First_Name = ?, Last_Name = ?, Location = ?, Email = ?, Education = ?, About = ? WHERE id = ?', 
  [First_Name, Last_Name, Location, Email, Education, About, req.params.id], (err, rows) => {
    if (!err) {
      pool.query('SELECT * FROM user WHERE id = ?', [req.params.id], (err, rows) => {
        if (!err) {
          res.render('edit-user', { rows, alert: `${First_Name} has been updated.` });
        } else {
          console.log(err);
        }
      });
    } else {
      console.log(err);
    }
  });
};


// Delete User
exports.delete = (req, res) => {
  pool.query('DELETE FROM user WHERE id = ?', [req.params.id], (err, rows) => {
    if (!err) {
      let removedUser = encodeURIComponent('User successfully removed.');
      res.redirect('/?removed=' + removedUser);
    } else {
      console.log(err);
    }
  });
};
    

// Placeholder for learner route
exports.learner = (req, res) => {
  res.render('learner');
};

// Placeholder for add route
exports.add = (req, res) => {
  res.render('add');
};

// Placeholder for index route
exports.index = (req, res) => {
  res.render('index');
};

