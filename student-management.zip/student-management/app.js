const express = require('express');
const exphbs = require('express-handlebars');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware for parsing request bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use(express.static('public'));

// Setup Handlebars templating engine
const handlebars = exphbs.create({ extname: '.hbs' });
app.engine('.hbs', handlebars.engine);
app.set('view engine', '.hbs');

// Import routes
const userRoutes = require('./server/routes/user');
app.use('/', userRoutes);





// Start the server
app.listen(port, () => console.log(`Server is running on port ${port}`));
